Q5 Run main.m
Q6 Run main.m and expand figure for better visibility

